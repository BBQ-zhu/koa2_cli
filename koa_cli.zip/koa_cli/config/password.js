const crypto = require('crypto')

const md5pw = (password) => {
    const md5 = crypto.createHash('md5');
    const result = md5.update(password).digest('hex'); //hex表示最终为十六进制
    return result;
}

module.exports = md5pw